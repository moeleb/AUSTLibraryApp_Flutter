package com.example.libraryproj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
